module.exports = require('../../src/js/uikit').default;
