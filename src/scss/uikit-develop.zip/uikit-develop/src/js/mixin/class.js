export default {

    init() {
        this.$addClass(this.$name);
    }

}
